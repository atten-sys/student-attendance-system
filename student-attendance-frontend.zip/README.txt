STUDENT ATTENDANCE FRONTEND
============================

The frontend is preconfigured for:
https://student-attendance-api.junmercado1925.workers.dev

DEPLOY TO GITHUB PAGES
1. Extract this ZIP.
2. Open the frontend folder.
3. Upload the CONTENTS of frontend/ to the root of your GitHub repository
   (or upload the frontend folder and configure Pages to use that folder).
4. In GitHub: Settings > Pages > Deploy from a branch > main > /(root) > Save.
5. Open the published site and sign in using an administrator account already
   created in your Worker/D1 database.

IMPORTANT API CONTRACT
The Worker endpoints explicitly provided were:
GET /api/health
GET/POST /api/users
GET/PUT/DELETE /api/users/:id
POST /api/auth/login
POST /api/auth/refresh

The frontend also calls these conventional endpoints for features requested:
GET /api/attendance?date=YYYY-MM-DD
POST /api/attendance/scan
POST /api/attendance/manual
GET /api/reports/attendance?from=YYYY-MM-DD&to=YYYY-MM-DD
GET/PUT /api/settings

Those attendance, reports and settings routes were not included in the supplied
Worker API list. They must exist in the Worker before those screens can save or
load those features. The UI displays the API error rather than pretending data
was saved. Check the Worker response field names if your API uses a different
contract; adjust frontend/js files accordingly.

LOGIN
Login submits identity under email, username and identity plus password, to
support common login handlers. The Worker should return access_token and
optionally refresh_token (or token/accessToken aliases), and optionally user.

QR CAMERA
Camera access requires HTTPS (GitHub Pages qualifies) and browser permission.
BarcodeDetector is supported in Chromium browsers; manual token entry remains
available where unsupported. QR tokens should be opaque, unguessable tokens;
never put student personal information directly in QR contents.

SECURITY
This is a static frontend. Authentication and authorization must be enforced
by the Worker on every protected API route. Configure CORS for your GitHub Pages
origin, use secure token rotation, hash QR tokens at rest, and do not expose
admin secrets in frontend files.
